--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aparatos_biometricos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aparatos_biometricos (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    serial character varying(100) NOT NULL,
    ip_address character varying(15),
    puerto integer DEFAULT 4370,
    ubicacion character varying(200),
    estado character varying(20) DEFAULT 'ACTIVO'::character varying,
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.aparatos_biometricos OWNER TO postgres;

--
-- Name: aparatos_biometricos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aparatos_biometricos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aparatos_biometricos_id_seq OWNER TO postgres;

--
-- Name: aparatos_biometricos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.aparatos_biometricos_id_seq OWNED BY public.aparatos_biometricos.id;


--
-- Name: postulantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.postulantes (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    cedula character varying(20) NOT NULL,
    fecha_nacimiento date,
    telefono character varying(20),
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    usuario_registrador integer,
    id_k40 integer,
    huella_dactilar bytea,
    observaciones text,
    edad integer,
    unidad character varying(50),
    dedo_registrado character varying(10),
    registrado_por text,
    aparato_id integer,
    uid_k40 integer,
    usuario_ultima_edicion character varying(100),
    fecha_ultima_edicion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    sexo character varying(10)
);


ALTER TABLE public.postulantes OWNER TO postgres;

--
-- Name: postulantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.postulantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.postulantes_id_seq OWNER TO postgres;

--
-- Name: postulantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.postulantes_id_seq OWNED BY public.postulantes.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    usuario character varying(50) NOT NULL,
    contrasena character varying(255) NOT NULL,
    rol character varying(20) DEFAULT 'USUARIO'::character varying NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    grado character varying(50),
    cedula character varying(20),
    numero_credencial character varying(50),
    telefono character varying(20),
    primer_inicio boolean DEFAULT true,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: aparatos_biometricos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aparatos_biometricos ALTER COLUMN id SET DEFAULT nextval('public.aparatos_biometricos_id_seq'::regclass);


--
-- Name: postulantes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulantes ALTER COLUMN id SET DEFAULT nextval('public.postulantes_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: aparatos_biometricos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aparatos_biometricos (id, nombre, serial, ip_address, puerto, ubicacion, estado, fecha_registro) FROM stdin;
5	K40V2 - Entrada	ZK987654321	192.168.100.202	4370	Entrada Principal	ACTIVO	2025-08-02 00:32:49.76733
6	K40V2 - Oficina	ZK456789123	192.168.100.203	4370	Oficina Administrativa	ACTIVO	2025-08-02 00:32:49.76733
4	ANAPOL 1	A8MX193760004	192.168.100.201	4370	Recepción Principal	ACTIVO	2025-08-02 00:32:49.76733
7	COLEPOL 1	A8MX193760002	192.168.100.201	4370	COLEPOL - Unidad Principal	ACTIVO	2025-08-07 11:54:53.369554
8	ANAPOL 2	PAS4241300509	\N	4370	\N	ACTIVO	2025-08-07 17:50:46.671028
9	Aparato de Prueba	TEST-001	192.168.1.100	4370	Oficina Principal - Modo Prueba	ACTIVO	2025-08-08 07:44:13
10	PRUEBA	0X0AB0	192.168.100.201	4370	Modo Prueba - Sin Conexión	PRUEBA	2025-08-08 07:51:05.759537
\.


--
-- Data for Name: postulantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.postulantes (id, nombre, apellido, cedula, fecha_nacimiento, telefono, fecha_registro, usuario_registrador, id_k40, huella_dactilar, observaciones, edad, unidad, dedo_registrado, registrado_por, aparato_id, uid_k40, usuario_ultima_edicion, fecha_ultima_edicion, sexo) FROM stdin;
46	JUAN CARLOS	GONZÁLEZ	12345678	1990-05-15	0981-123-456	2025-08-08 07:44:53	1	\N	\N	\N	33	Unidad 1	PD	Admin General	9	1001	\N	2025-08-08 07:44:53.968101	Hombre
47	MARÍA ELENA	RODRÍGUEZ	23456789	1988-12-03	0982-234-567	2025-08-08 07:44:53	1	\N	\N	\N	35	Unidad 2	ID	Admin General	9	1002	\N	2025-08-08 07:44:53.968101	Mujer
48	CARLOS ALBERTO	LÓPEZ	34567890	1995-08-22	0983-345-678	2025-08-08 07:44:53	1	\N	\N	\N	28	Unidad 1	MD	Admin General	9	1003	\N	2025-08-08 07:44:53.968101	Hombre
49	ANA LUCÍA	MARTÍNEZ	45678901	1992-03-10	0984-456-789	2025-08-08 07:44:53	1	\N	\N	\N	31	Unidad 3	AD	Admin General	9	1004	\N	2025-08-08 07:44:53.968101	Mujer
50	ROBERTO JOSÉ	SILVA	56789012	1987-11-18	0985-567-890	2025-08-08 07:44:53	1	\N	\N	\N	36	Unidad 2	PI	Admin General	9	1005	\N	2025-08-08 07:44:53.968101	Hombre
52	SAM	SEPIOL	3333333	2003-03-03	0982333333	2025-08-08 07:53:23	1	\N	\N	\N	22	Unidad 1	PD	Oficial Segundo Guillermo Andres Recalde Valdez	10	9516	\N	2025-08-08 07:53:58.964783	Hombre
19	CANELA	CANELITA	12312312	2008-08-08	0982316160	2025-08-03 14:20:38	1	\N	\N	\N	16	Unidad 4	MeD	Comisario Admin General	4	3	\N	2025-08-04 10:04:27.802055	Hombre
21	STEPZ	PASITOS	1616166	2000-08-03	0987506030	2025-08-03 15:47:28	4	\N	\N	\N	25	Unidad 2	MD	Oficial Segundo GUILLERMO RECALDE	4	4	\N	2025-08-04 10:04:27.802055	Hombre
22	ST2	SS2	997633	1996-08-03	098705060	2025-08-03 15:49:18	5	\N	\N	\N	29	Unidad 2	ID	Oficial Inspector ARV VRE	4	5	\N	2025-08-04 10:04:27.802055	Mujer
23	CADETE	BISO	669887	2007-07-07	0987306050	2025-08-03 17:15:50	1	\N	\N	\N	18	Unidad 4	PI	Comisario Admin General	4	6	\N	2025-08-04 10:04:27.802055	Mujer
24	AGREGAR	POSTULANTE	8898776	2008-08-09	0987306709	2025-08-03 17:30:10	1	\N	\N	\N	16	Unidad 4	AD	Comisario Admin General	4	7	\N	2025-08-04 10:04:27.802055	Hombre
25	PRUEBA	PRUEEBA	6669330	1998-08-09	09870808080	2025-08-03 17:53:07	1	\N	\N	\N	26	Unidad 4	MeI	Comisario Admin General	4	8	\N	2025-08-04 10:04:27.802055	Mujer
28	XWX	WWQE	663005	2008-08-08	0983660115	2025-08-03 18:09:18	1	\N	\N	\N	16	Unidad 4	PI	Comisario Admin General	4	2	\N	2025-08-04 10:04:27.802055	Hombre
20	SMA	IWIW	5566335	2010-10-08	098150500	2025-08-03 14:23:45	1	\N	\N		14	Unidad 1	PD	Comisario Admin General	4	1	\N	2025-08-04 10:04:27.802055	Hombre
26	SAM	SEPIOL	336600	2001-08-08	0987306050	2025-08-03 18:02:23	1	\N	\N		23	Unidad 1	PI	Comisario Admin General	4	2	Admin General	2025-08-04 10:06:52.910639	Mujer
15	SAM	SAM	666666	1990-01-01	0987808080	2025-08-02 15:13:14	2	\N	\N		35	Unidad 3	PI	2	4	1	Admin General	2025-08-04 10:10:43.971689	Hombre
18	PENELOPE	VANELLOP	9879956	2001-08-08	0983151515	2025-08-03 14:16:18	1	\N	\N		23	Unidad 1	PD	Comisario Admin General	4	2	Admin General	2025-08-04 10:13:57.615119	Hombre
17	XWX	XWXX	6666669	1990-01-01	098700300	2025-08-02 15:36:05	3	\N	\N		35	Unidad 4	PD	Suboficial Segundo evelin barrios	4	1	ARV VRE	2025-08-04 10:26:22.982829	Hombre
27	SAM	SSEPIOL	663366	2000-07-08	0982301566	2025-08-03 18:04:23	1	\N	\N	Observación de prueba	25	Unidad 1	ID	Comisario Admin General	4	3	ARV VRE	2025-08-04 10:29:07.7283	Mujer
29	SAMUEL	ROMERO	6663448	2007-07-07	0987336558	2025-08-04 18:27:46	1	\N	\N	\N	18	Unidad 1	MeD	Comisario Admin General	4	1	\N	2025-08-04 18:29:10.175025	Hombre
30	ROCIO	CACERES BERNAL	669336	2007-07-08	0982556887	2025-08-04 18:34:36	1	\N	\N	\N	18	Unidad 3	PI	Comisario Admin General	4	2	\N	2025-08-04 18:35:06.638532	Hombre
31	MIRAI	RECALDE BARRIOS	6698872	2000-12-31	0987223665	2025-08-04 21:05:41	1	\N	\N	\N	24	Unidad 1	MeD	Comisario Admin General	4	3	\N	2025-08-04 21:06:22.2601	Hombre
32	SALCHITRUCHO	ROPERO	6693000	2008-08-08	0982336554	2025-08-04 21:11:50	1	\N	\N	\N	16	Unidad 4	MD	Comisario Admin General	4	1	\N	2025-08-04 21:12:31.59983	Hombre
33	SALCHITRUCHO	ROPEROU	555666	2008-08-08	0982331156	2025-08-04 21:12:43	1	\N	\N	\N	16	Unidad 3	PD	Comisario Admin General	4	1	\N	2025-08-04 21:13:21.676045	Hombre
34	SSSWW	XXQW	6663311	2001-09-09	0983366887	2025-08-04 21:26:24	1	\N	\N	\N	23	Unidad 2	PD	Comisario Admin General	4	2	\N	2025-08-04 21:26:57.669844	Mujer
35	S651	1651	16510	2009-09-09	6151656	2025-08-04 21:27:43	1	\N	\N	\N	15	Unidad 2	ID	Comisario Admin General	4	2	\N	2025-08-04 21:28:50.022012	Hombre
36	XAVI	HERNANDEZ	98765432	2001-08-08	0986336552	2025-08-06 23:27:37	1	\N	\N	\N	23	Unidad 4	AD	Oficial Segundo Guillermo Andres Recalde Valdez	4	4	\N	2025-08-06 23:28:13.862724	Hombre
37	XXXXXXX	WWWWW	6682215	2008-08-08	0986666666	2025-08-07 12:04:38	5	\N	\N	\N	16	Unidad 2	PD	Oficial Segundo GUILLERMO ANDRES RECALDE VALDEZ	7	2367	\N	2025-08-07 12:07:27.947369	Hombre
38	SSSA	WWX	6693002	2007-07-07	08960060	2025-08-07 16:52:38	1	\N	\N	\N	18	Unidad 1	PD	Comisario Admin General	7	2370	\N	2025-08-07 16:53:25.080102	Hombre
39	X65E	X61QEW	6692368	2000-01-01	225566878	2025-08-07 16:55:34	1	\N	\N	\N	25	Unidad 1	PD	Comisario Admin General	7	2368	\N	2025-08-07 16:56:20.555883	Hombre
40	ANAKIN	SKYWALKER	2369001	2001-08-08	0982369001	2025-08-07 16:58:22	1	\N	\N	\N	23	Unidad 1	ID	Comisario Admin General	7	2369	\N	2025-08-07 16:59:27.701303	Hombre
41	ANAPOL2	PRUEBA2	5000000	2000-10-01	0982350530	2025-08-07 17:36:14	1	\N	\N	\N	24	Unidad 1	II	Comisario Admin General	4	5	\N	2025-08-07 17:36:46.991378	Mujer
42	SSSSX	WWWWX	2371000	2000-02-01	0982315153	2025-08-07 17:42:29	1	\N	\N	\N	25	Unidad 2	MeD	Comisario Admin General	7	2371	\N	2025-08-07 17:43:29.486788	Hombre
43	XQWIEJ	XIQEWJ	2371025	2000-01-01	0982115155	2025-08-07 17:45:07	1	\N	\N	\N	25	Unidad 1	AD	Comisario Admin General	7	2370	\N	2025-08-07 17:46:02.841207	Mujer
44	PRUEBA	SEMIFINAL NUEVO	782025	2001-01-01	0982311515	2025-08-07 17:50:54	5	\N	\N	\N	24	Unidad 4	PD	Oficial Segundo GUILLERMO ANDRES RECALDE VALDEZ	8	3000	\N	2025-08-07 17:51:28.974538	Hombre
54	ELPE	LOTUDO	651	2006-07-08	6516518	2025-08-08 17:21:34	1	\N	\N	\N	19	Unidad 2	ID	Oficial Segundo Guillermo Andres Recalde Valdez	8	3000	\N	2025-08-08 17:21:57.267749	Mujer
55	GUILLERMO	RECALDE	5995260	1997-11-09	0982311865	2025-08-08 17:26:39	1	\N	\N	\N	27	Unidad 1	PD	Oficial Segundo Guillermo Andres Recalde Valdez	8	1	\N	2025-08-08 17:26:59.394553	Mujer
56	GUILLERMO	INDICE	66669999	2002-08-08	0982222222	2025-08-08 18:02:51	5	\N	\N	\N	23	Unidad 2	ID	Oficial Segundo GUILLERMO ANDRES RECALDE VALDEZ	8	2	\N	2025-08-08 18:03:12.181339	Hombre
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, usuario, contrasena, rol, nombre, apellido, grado, cedula, numero_credencial, telefono, primer_inicio, fecha_creacion) FROM stdin;
1	admin	$2b$12$a.zvbIgC6.AuPp8us75ti.WRqHrFAV/moLS.0cLTVRql1y5/xQoPq	SUPERADMIN	Admin	General	Comisario	00000000	CRED-ADMIN	0000000000	f	2025-08-01 23:59:31.738756
4	adm	$2b$12$YWvs2BciKhN16c4WM11CteCjzV7wCCDI4R4yzDh56N0dqtYLKNSKG	SUPERADMIN	GUILLERMO	RECALDE	Oficial Segundo	5995260	60149	0982311865	f	2025-08-03 15:43:29.094734
6	1.wdsd	$2b$12$VJAW9AiW16ZeJy5CbEByMOwxx4OipKL1jZ6qtl6WGK16ACXttPnei	USUARIO	WALTER DANIEL	SANCHEZ DUARTE	Comisario Principal	5555555	655555	0987660055	t	2025-08-05 21:24:53.462143
8	eabr	$2b$12$11F81Yl5rp5nIGj0UIQhKOpsB8.NoAN1dnTdVKB9Xy8qTXeJZkIvu	USUARIO	EVELIN ANDREA	BARRIOS DE RECALDE	Suboficial Segundo	4983448	61929	0986491257	f	2025-08-05 21:25:56.994665
5	garv	$2b$12$8sWf7zQ.ekRG3pVYP77DbuC.Ziogc9Zh0yG66kOh.ISZ9yDb4iNVW	SUPERADMIN	GUILLERMO ANDRES	RECALDE VALDEZ	Oficial Segundo	5995260	60149	0982311865	f	2025-08-03 15:49:05.45072
\.


--
-- Name: aparatos_biometricos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aparatos_biometricos_id_seq', 10, true);


--
-- Name: postulantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.postulantes_id_seq', 56, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 8, true);


--
-- Name: aparatos_biometricos aparatos_biometricos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aparatos_biometricos
    ADD CONSTRAINT aparatos_biometricos_pkey PRIMARY KEY (id);


--
-- Name: aparatos_biometricos aparatos_biometricos_serial_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aparatos_biometricos
    ADD CONSTRAINT aparatos_biometricos_serial_key UNIQUE (serial);


--
-- Name: postulantes postulantes_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulantes
    ADD CONSTRAINT postulantes_cedula_key UNIQUE (cedula);


--
-- Name: postulantes postulantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulantes
    ADD CONSTRAINT postulantes_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_usuario_key UNIQUE (usuario);


--
-- Name: postulantes postulantes_aparato_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulantes
    ADD CONSTRAINT postulantes_aparato_id_fkey FOREIGN KEY (aparato_id) REFERENCES public.aparatos_biometricos(id);


--
-- PostgreSQL database dump complete
--

